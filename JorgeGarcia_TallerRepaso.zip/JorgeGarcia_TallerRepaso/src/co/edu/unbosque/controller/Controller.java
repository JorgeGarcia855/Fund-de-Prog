package co.edu.unbosque.controller;

import co.edu.unbosque.model.Operaciones;
import co.edu.unbosque.view.View;

public class Controller {
	
	private Operaciones operacion;
	private View gui;
	
	public Controller() {
		operacion = new Operaciones();
		gui = new View();
		funcionar();
	}
	
	public void funcionar() {
		String letra = "";
		int mes, num = 0;
		try {
			letra = gui.pedirDato("Ingrese primera letra de tu apellido: ");
			if (letra.matches("^[a-zA-Z]*$")) {
				operacion.setLetra(letra);
			}else {
				gui.mostrarResultados("Debe ingresar una letra valida.");
				System.exit(1);
			}
			
			mes = gui.pedirDatoEntero("Ingrese mes de nacimiento: ");
			if (mes>=1 && mes<=12) {
				operacion.setMes(mes);
			}else {
				gui.mostrarResultados("Debe ingresar tu mes de nacimiento (1-12)");
				System.exit(1);
			}
			
			num = gui.pedirDatoEntero("Ingrese el ultimo digito de tu numero de telefono: ");
			if (num>=0&&num<=9) {
				operacion.setNum(num);
			} else {
				gui.mostrarResultados("Debe ingresar solo un digito.");
				System.exit(1);
			}
		} catch (NumberFormatException e) {
			gui.mostrarResultados("Debe ingresar un numero entero.");
			System.exit(1);
		}
		gui.mostrarResultados(operacion.letraApellido()+operacion.mesNacimiento()+operacion.numeroTelefono());
	}

}
