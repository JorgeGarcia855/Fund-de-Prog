package co.edu.unbosque.model;

public class Operaciones {
	
	private String letra;
	private int num, mes;
	
	public Operaciones() {
		letra = "";
		mes = 0;
		num = 0;
	}
	
	public String letraApellido() {
		String titulo1 = "";
		switch (letra.toUpperCase()) {
			case "A":
				titulo1 = "La Verdadera ";
				break;
			case "B":
				titulo1 = "La Excitante ";
				break;
			case "C":
				titulo1 = "La Horripilante ";
				break;
			case "D":
				titulo1 = "La Alegre ";
				break;
			case "E":
				titulo1 = "La Fatal ";
				break;
			case "F":
				titulo1 = "La Apasionante ";
				break;
			case "G":
				titulo1 = "La Tr�gica ";
				break;
			case "H":
				titulo1 = "La Sangrienta ";
				break;
			case "I":
				titulo1 = "La Famosa";
				break;
			case "J":
				titulo1 = "La Gran ";
				break;
			case "K":
				titulo1 = "La Penosa ";
				break;
			case "L":
				titulo1 = "La Triste ";
				break;
			case "M":
				titulo1 = "La Desastrosa ";
				break;
			case "N":
				titulo1 = "La Hermosa ";
				break;
			case "O":
				titulo1 = "La Oscura ";
				break;
			case "P":
				titulo1 = "La Gloriosa ";
				break;
			case "Q":
				titulo1 = "La Infeliz ";
				break;
			case "R":
				titulo1 = "La Emocionante ";
				break;
			case "S":
				titulo1 = "La Fant�stica ";
				break;
			case "T":
				titulo1 = "La Terror�fica ";
				break;
			case "U":
				titulo1 = "La Aburrida ";
				break;
			case "V":
				titulo1 = "La Incre�ble ";
				break;
			case "W":
				titulo1 = "La Desgraciada ";
				break;
			case "X":
				titulo1 = "La Lamentable ";
				break;
			case "Y":
				titulo1 = "La C�mica ";
				break;
			case "Z":
				titulo1 = "La Miserable ";
				break;

			default:
				
				
				break;
		}
		return titulo1;
	}
	
	public String mesNacimiento() {
		String titulo2 = "";
		switch (mes) {
			case 1:
				titulo2 = "Haza�a ";
				break;
			case 2:
				titulo2 = "Reencarnaci�n ";
				break;
			case 3:
				titulo2 = "Batalla ";
				break;	
			case 4:
				titulo2 = "Existencia ";
				break;
			case 5:
				titulo2 = "Muerte ";
				break;
			case 6:
				titulo2 = "Misi�n ";
				break;
			case 7:
				titulo2 = "Venganza ";
				break;		
			case 8:
				titulo2 = "Anecdota ";
				break;	
			case 9:
				titulo2 = "Vida ";
				break;
			case 10:
				titulo2 = "Leyenda ";
				break;
			case 11:
				titulo2 = "Historia ";
				break;		
			case 12:
				titulo2 = "Biografia ";
				break;
				
			default:
				break;
		}
		return titulo2; 
	}
	
	public String numeroTelefono() {
		String titulo3 = "";
		switch (num) {
			case 0:
				titulo3 = "de un Bipolar";
				break;
			case 1:
				titulo3 = "de un Asesino/a";
				break;
			case 2:
				titulo3 = "de un Loco/a";
				break;
			case 3:
				titulo3 = "de un Adicto/a a los memes";
				break;	
			case 4:
				titulo3 = "de un So�ador/a";
				break;
			case 5:
				titulo3 = "de un Genio/a incomprendido/a";
				break;
			case 6:
				titulo3 = "de un Simbolo Sexual";
				break;
			case 7:
				titulo3 = "de un Alcoholico/a";
				break;	
			case 8:
				titulo3 = "de un Guerrero/a";
				break;
			case 9:
				titulo3 = "de un Aventurero/a";
				break;
				
			default:
				break;
		}
		return titulo3;
	}

	public String getLetra() {
		return letra;
	}

	public void setLetra(String letra) {
		this.letra = letra;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		this.mes = mes;
	}

}
